/*******************************************************************
* Name: Haley Altaie
* Date: 10/26/25
* Assignment: SDC330 Course Project - Week 3
*
* Interface for classes that can generate reports.
* Demonstrates: Interface usage
*/
public interface Reportable {
    public String generateReport();
}
